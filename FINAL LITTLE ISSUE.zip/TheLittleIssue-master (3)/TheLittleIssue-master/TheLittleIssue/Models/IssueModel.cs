﻿namespace TheLittleIssue.Models
{
    public class IssueModel
    {
        public string? Id { get; set; }
        public string? Title { get; set; }
        public string? PdfUrl { get; set; }
        public string? CoverUrl { get; set; }
    }
}
