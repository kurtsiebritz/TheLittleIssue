﻿namespace TheLittleIssue.Models
{
    public class UserHistoryModel
    {
        public string ArticleTitle { get; set; }
        public int PageNumber { get; set; }
        public DateTime ReadAt { get; set; }
    }
}
